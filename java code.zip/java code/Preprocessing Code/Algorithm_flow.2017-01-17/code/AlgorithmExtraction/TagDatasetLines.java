package AlgorithmExtraction;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import Model.AlgorithmRepresentation;
import Model.PdfDocument;
import PdfSegmentation.PdfExtractor;
import Util.Directory;
import Util.Util;

public class TagDatasetLines {
	public static void main(String args[]){

		Writer writer = null;
		int iteration=1;
		String file= null;

		//Vector<String> TaggedTextFiles = Directory.listAllFiles("pseudocode_and_sbs/RawDataRename withdataset lines tagged", ".tagged.txt", 1);
		//PorterStemmer stemer=new PorterStemmer();
		String file1="";
		String lineText=null;
		String lineText1=null;
		BufferedReader br1 =null; 
		BufferedWriter bw1=null;
		try {
			
			System.out.println("In Try");
			CSVReader reader = new CSVReader(new FileReader("./Dataset names records_3.csv"));
			String [] nextLine;
			while ((nextLine = reader.readNext()) != null) {

				lineText=nextLine[1];
				String lines[] = lineText.split("\\r?\\n");
				System.out.println("lineText::::"+lines[0]);
				lineText1="397|[::-::]Training and test data are taken from an electronic ";
				lineText1 = lineText1.replaceAll("|[::-::]", "|47[::-::]");
				System.out.println("Line::::::::::::::" + lineText1 );
				file1="E:/PhD/Eclipse workspace/algorithm_flow.2017-01-17/pseudocode_and_sbs/Rawdata Original/"+nextLine[0]+".tagged.txt";
				System.out.println(file1);
				BufferedWriter bw = new BufferedWriter(new FileWriter(new File(file1)));
				BufferedReader br = new BufferedReader(new FileReader(new File(file1)));
		
					 while((lineText1=br.readLine()) != null ){
						 System.out.println("step 1"+lineText1);
						 String line=lineText1;
						 //if (line.contains("::]"))
						 {
							line = line.substring(line.indexOf("::]") + 3).trim();
							//for (String keywords : lines)
							{
								//if (line.contains(keywords))
								{
									lineText1="397|[::-::]Training and test data are taken from an electronic ";
									lineText1 = lineText1.replaceAll("|[::", "|47[::");
									System.out.println("Line::::::::::::::" + lineText1 );
				                    bw.write(lineText1);
								}
							}
						//;
					}
				}
					 
					    
					 //bw.flush();
					 //bw.close();
					 //br.close();
			}
		
	


			//System.out.println("Done");


		
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (writer != null) {
				try {
					writer.flush();
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}



		

	}
}
