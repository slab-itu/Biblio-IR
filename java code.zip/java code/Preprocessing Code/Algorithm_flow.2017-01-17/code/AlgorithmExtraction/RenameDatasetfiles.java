
package AlgorithmExtraction;
import java.io.*;
public class RenameDatasetfiles {
	

	//public class RenameFile {
	    public static void main(String[] args) {
	        // change file names in 'Directory':
	    	
	        //String absolutePath = "E:\\MY DATA\\PhD\\IQRA DATA\\Eclipse workspace\\algorithm_flow.2017-01-17\\\\";
	        String absolutePath="E:\\MY DATA\\PhD\\IQRA DATA\\Eclipse workspace\\DetectCaptions\\pseudocode_and_sbs\\corpus for Dataset line extraction\\";
	        //D:\PhD\Eclipse workspace\algorithm_flow.2017-01-17\pseudocode_and_sbs\Complete258_Syn
	        File dir = new File(absolutePath);
	        //String newPath="E:\\MY DATA\\PhD\\IQRA DATA\\Eclipse workspace\\DetectCaptions\\pseudocode_and_sbs\\Datasetremane\\";
	       // File newDir=new File(newPath);
	        File[] filesInDir = dir.listFiles();
	        int i = 258;
	        for(File file:filesInDir) {
	            i++;
	            String name = file.getName();
	            if(name.contains("labeled")){
	            name= name.substring(0,name.indexOf(".labeled")).trim();
	            }
	            //String newName = name+" Myfile " + i + ".txt";
	            String newName = name+".tagged.txt";
	            //new
	            //String newPath = "E:\\MY DATA\\PhD\\IQRA DATA\\Eclipse workspace\\algorithm_flow.2017-01-17\\ACL txt\\RenameACL Synopsis\\" + newName;
	            String newPath="E:\\MY DATA\\PhD\\IQRA DATA\\Eclipse workspace\\DetectCaptions\\pseudocode_and_sbs\\Datasetremane\\"+newName;
	            //String newPath="E:\\MY DATA\\PhD\\IQRA DATA\\Eclipse workspace\\DetectCaptions\\pseudocode_and_sbs\\new\\";
	            file.renameTo(new File(newPath));
	            System.out.println(name + " changed to " + newName);
	        }
	    } // close main()
	} //

