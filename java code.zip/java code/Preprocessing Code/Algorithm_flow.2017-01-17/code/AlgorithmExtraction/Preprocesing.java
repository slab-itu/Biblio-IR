package AlgorithmExtraction;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;
import java.util.stream.IntStream;
import java.io.File;



import com.opencsv.CSVReader;

import Model.PdfDocument;
import Model.TextLine;
import PdfSegmentation.PdfExtractor;
import Util.Directory;
import Util.Util;

public class Preprocesing{
	public static int count_words(String line){
		return (line.split(" ")).length;
		//String trim = line.trim();
		//if (trim.isEmpty())
		//  return 0;
		//return line.split("\\s+").length+1;
	}
	public static String StemWords(String text) {
		//	System.out.println("hellow .......");
		BreakIterator wordIterator = BreakIterator.getWordInstance();
		String newStr = new String();

		wordIterator.setText(text);
		int start = wordIterator.first();
		int end = wordIterator.next();

		while (end != BreakIterator.DONE) {
			String word = text.substring(start,end);

			stemmer p=new stemmer();
			newStr += p.getStem(word);

			start = end;
			end = wordIterator.next();
		}
		//System.out.println("hellow ......."+newStr);

		return newStr;
	}

	public static String removeStopWords(String tweet)
	{
		String res = "";	
		for (Character c : tweet.toCharArray()) {
			if(c != ' ')
			{
				if(Character.isLetter(c))
					res += c;
			}
			else{
				res += " ";
			}
		}		
		res=res.toLowerCase();
		//		    System.out.println("To lower::"+res);
		String[] stopwords = {"a", "as", "able", "about", "above", "according", "accordingly", "across", "actually", "after", "afterwards", "again", "against", "aint", "all", "allow", "allows", "almost", "alone", "along", "already", "also", "although", "always", "am", "among", "amongst", "an", "and", "another", "any", "anybody", "anyhow", "anyone", "anything", "anyway", "anyways", "anywhere", "apart", "appear", "appreciate", "appropriate", "are", "arent", "around", "as", "aside", "ask", "asking", "associated", "at", "available", "away", "awfully", "be", "became", "because", "become", "becomes", "becoming", "been", "before", "beforehand", "behind", "being", "believe", "below", "beside", "besides", "best", "better", "between", "beyond", "both", "brief", "but", "by", "cmon", "cs", "came", "can", "cant", "cannot", "cant", "cause", "causes", "certain", "certainly", "changes", "clearly", "co", "com", "come", "comes", "concerning", "consequently", "consider", "considering", "contain", "containing", "contains", "corresponding", "could", "couldnt", "course", "currently", "definitely", "described", "despite", "did", "didnt", "different", "do", "does", "doesnt", "doing", "dont", "done", "down", "downwards", "during", "each", "edu", "eg", "eight", "either", "else", "elsewhere", "enough", "entirely", "especially", "et", "etc", "even", "ever", "every", "everybody", "everyone", "everything", "everywhere", "ex", "exactly", "example", "except", "far", "few", "ff", "fifth", "first", "five", "followed", "following", "follows", "for", "former", "formerly", "forth", "four", "from", "further", "furthermore", "get", "gets", "getting", "given", "gives", "go", "goes", "going", "gone", "got", "gotten", "greetings", "had", "hadnt", "happens", "hardly", "has", "hasnt", "have", "havent", "having", "he", "hes", "hello", "help", "hence", "her", "here", "heres", "hereafter", "hereby", "herein", "hereupon", "hers", "herself", "hi", "him", "himself", "his", "hither", "hopefully", "how", "howbeit", "however", "i", "id", "ill", "im", "ive", "ie", "if", "ignored", "immediate", "in", "inasmuch", "inc", "indeed", "indicate", "indicated", "indicates", "inner", "insofar", "instead", "into", "inward", "is", "isnt", "it", "itd", "itll", "its", "its", "itself", "just", "keep", "keeps", "kept", "know", "knows", "known", "last", "lately", "later", "latter", "latterly", "least", "less", "lest", "let", "lets", "like", "liked", "likely", "little", "look", "looking", "looks", "ltd", "mainly", "many", "may", "maybe", "me", "mean", "meanwhile", "merely", "might", "more", "moreover", "most", "mostly", "much", "must", "my", "myself", "name", "namely", "nd", "near", "nearly", "necessary", "need", "needs", "neither", "never", "nevertheless", "new", "next", "nine", "no", "nobody", "non", "none", "noone", "nor", "normally", "not", "nothing", "novel", "now", "nowhere", "obviously", "of", "off", "often", "oh", "ok", "okay", "old", "on", "once", "one", "ones", "only", "onto", "or", "other", "others", "otherwise", "ought", "our", "ours", "ourselves", "out", "outside", "over", "overall", "own", "particular", "particularly", "per", "perhaps", "placed", "please", "plus", "possible", "presumably", "probably", "provides", "que", "quite", "qv", "rather", "rd", "re", "really", "reasonably", "regarding", "regardless", "regards", "relatively", "respectively", "right", "said", "same", "saw", "say", "saying", "says", "second", "secondly", "see", "seeing", "seem", "seemed", "seeming", "seems", "seen", "self", "selves", "sensible", "sent", "serious", "seriously", "seven", "several", "shall", "she", "should", "shouldnt", "since", "six", "so", "some", "somebody", "somehow", "someone", "something", "sometime", "sometimes", "somewhat", "somewhere", "soon", "sorry", "specified", "specify", "specifying", "still", "sub", "such", "sup", "sure", "ts", "take", "taken", "tell", "tends", "th", "than", "thank", "thanks", "thanx", "that", "thats", "thats", "the", "their", "theirs", "them", "themselves", "then", "thence", "there", "theres", "thereafter", "thereby", "therefore", "therein", "theres", "thereupon", "these", "they", "theyd", "theyll", "theyre", "theyve", "think", "third", "this", "thorough", "thoroughly", "those", "though", "three", "through", "throughout", "thru", "thus", "to", "together", "too", "took", "toward", "towards", "tried", "tries", "truly", "try", "trying", "twice", "two", "un", "under", "unfortunately", "unless", "unlikely", "until", "unto", "up", "upon", "us", "use", "used", "useful", "uses", "using", "usually", "value", "various", "very", "via", "viz", "vs", "want", "wants", "was", "wasnt", "way", "we", "wed", "well", "were", "weve", "welcome", "well", "went", "were", "werent", "what", "whats", "whatever", "when", "whence", "whenever", "where", "wheres", "whereafter", "whereas", "whereby", "wherein", "whereupon", "wherever", "whether", "which", "while", "whither", "who", "whos", "whoever", "whole", "whom", "whose", "why", "will", "willing", "wish", "with", "within", "without", "wont", "wonder", "would", "would", "wouldnt", "yes", "yet", "you", "youd", "youll", "youre", "youve", "your", "yours", "yourself", "yourselves", "zero"};
		ArrayList<String> wordsList = new ArrayList<String>();   
		// String tweet = "Feeling miserable with the cold? Here's what you can do.";
		res = res.trim().replaceAll("\\s+", " ");
		//		         System.out.println("After trim:  " + res);
		String[] words = res.split(" ");
		for (String word : words) {
			wordsList.add(word);
		}

		for (int i = 0; i < wordsList.size(); i++) {
			// get the item as string
			for (int j = 0; j < stopwords.length; j++) {
				if (wordsList.contains(stopwords[j])) {
					wordsList.remove(stopwords[j]);//remove it
				}
			}
		}

		String listString="";
		for (String s : wordsList)
		{
			if(s.length()<= 2){
				s.replace("\\s+", "");
			}
		else{
			listString += s + " ";
			}
		}
		//String stem=StemWords(listString);
		//System.out.println("end:------"+stem);
		return listString;

	}




	@SuppressWarnings("resource")
	public static void main(String[] args){
		Writer writer = null;
		double word_density=0;
		String CaptionText="";
		String taggedTextFilename="";
		String pdfFilename="";
		int theroshold=8;
		List<Integer> num_words_per_line = new ArrayList<Integer>();
		Vector<String> pdfFiles = Directory.listAllFiles("pseudocode_and_sbs", "pdf", 1);
		Vector<String> TaggedTextFiles = Directory.listAllFiles("pseudocode_and_sbs/Without_Ref_abs", ".tagged.txt", 1);
		Vector<String> selectedlines= new Vector<String>();
		try {
			System.out.println("In Try");
			CSVReader reader = new CSVReader(new FileReader("./Synopsis.csv"));

			//writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("Top20matchedwithCaption.csv"), "UTF-8"));

			String [] nextLine;
			while ((nextLine = reader.readNext()) != null) {
				System.out.println("In reading");
				CaptionText=nextLine[1];
				//pdfFilename="pseudocode_and_sbs/"+nextLine[0]+".pdf";
				taggedTextFilename="pseudocode_and_sbs/Without_Ref_abs/"+nextLine[0]+".tagged.txt";
				String file="pseudocode_and_sbs/Processed/"+nextLine[0]+".tagged.txt";

				for(String f: TaggedTextFiles){
					//System.out.println("1:"+f);
					//System.out.println("2:"+ taggedTextFilename);
					//Util.jout("Going to extract: " + f + "\n");
					if(f.equals(taggedTextFilename)){
						Util.jout("Going to extract: " + f + "\n");

						try(BufferedReader br = new BufferedReader(new FileReader(new File(f)))) {
							for(String line; (line = br.readLine()) != null; ) {
								
								num_words_per_line.add(count_words(line));
							}
							
							br.close();
							BufferedReader br1 = new BufferedReader(new FileReader(new File(f)));
							Writer bw1 = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file),"UTF-8"));
							

							//This line is converting Arraylist to integer array and calculating 
							// Sum of all of it's values
							double average_num_word_line = (IntStream.of(num_words_per_line.stream().filter(i -> i != null).mapToInt(i -> i).toArray()).sum())/(num_words_per_line.size());
							System.out.println("Average line length:"+average_num_word_line);
							for(String line; (line = br1.readLine()) != null; ) {
								int index=line.indexOf("::]");
								String line_chunk=line.substring(0, index+3);
								line=line.substring(index+3);
								line=line.replaceAll("\\W+", " ");
								//line2=line2.substring(line2.indexOf("::]")).trim();
								line=line_chunk+line;
								int sum=count_words(line) + (count_words(line) - 1);
								int count=count_words(line);
								word_density = (double) count / sum;
								//System.out.println("Line text:"+line);

								if(line.contains("::]")){
									if((count_words(line.substring(line.indexOf("::]") + 3).trim()) >= theroshold && word_density >= 0.5 ))

									{
										/*System.out.println("Line text:"+line);
										System.out.println("density:"+word_density);
										System.out.println("line length:"+count_words(line.substring(line.indexOf("::]") + 3).trim()));*/
										
										line=line.substring(line.indexOf("::]") + 3).trim();
										
										bw1.write(line);
										((BufferedWriter) bw1).newLine();
										
									}
									
								}
							}

							
							bw1.flush();
							bw1.close();
							br1.close();
						}





					}

				}


			}


			//System.out.println("Done");


		}catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (writer != null) {
				try {
					writer.flush();
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}


	}
}



