package AlgorithmExtraction;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.opencsv.CSVReader;

import Util.Directory;
import Util.Util;

public class AddtestinglinestoSynopsis {
	

public static void main(String args[]){
	Writer writer = null;
	int iteration=1;
	String file= null;

	Vector<String> TaggedTextFiles = Directory.listAllFiles("pseudocode_and_sbs/Complete258_Syn", ".tagged.txt", 1);
	PorterStemmer stemer=new PorterStemmer();
	String file1="";
	String lineText=null;
	BufferedReader br1 =null; //new BufferedReader(new FileReader(new File(f)));
	BufferedWriter bw1=null;
	try {
		//writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("Top20matchedwithCaption.csv"), "UTF-8"));
		System.out.println("In Try");
		CSVReader reader = new CSVReader(new FileReader("./TestingLinesnew.csv"));
		String [] nextLine;
		while ((nextLine = reader.readNext()) != null) {

			lineText=nextLine[1];
			lineText=lineText.substring(0,lineText.length()-2).trim();
			System.out.println("lineText"+lineText);
			file1="pseudocode_and_sbs/Complete258_Syn/"+nextLine[0];
			System.out.println("In reading");
			
			
			
			for(String f: TaggedTextFiles){
				Util.jout("Going to extract 1:::: " + f + "\n");
				System.out.println("text::::::::::"+file1);
				if(f.equals(file1)){
					Util.jout("Matched file:::: Going to extract: " + f + "\n");
					iteration++;
					
					//br1 = new BufferedReader(new FileReader(new File(f)));
					bw1 = new BufferedWriter(new FileWriter(file1,true));
					bw1.write(" "+lineText);
					//Map<String,Double> mapper = new HashMap<>(); 
					//for(String line; (line = br1.readLine()) != null; ) {}
					bw1.flush();
					bw1.close();
					//br1.close();
				}
			}
		}


		//System.out.println("Done");


	}catch (FileNotFoundException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	} finally {
		if (writer != null) {
			try {
				writer.flush();
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}



	
} 
}
