package AlgorithmExtraction;
import java.util.Arrays;
import java.util.List;

public class PrecisionRecall {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String [] actual = new String[]{"F","F","F","F","F","T","F"};
		String [] system = new String[]{"T","F","F","F","F","T","F"};
		
		printPrecisionRecallConfusionMatrix(Arrays.asList(actual), Arrays.asList(system));
	}
	
	// List is an interface and ArrayList is a class, we can assign ArrayList in List
	// List<String> list = new ArrayList<Stirng>(); this is proper way to initialize an ArrayList
	public static void printPrecisionRecallConfusionMatrix(List<String> actualList, List<String> systemList){
		
		String [] actual = actualList.toArray(new String[actualList.size()]);
		String [] system = systemList.toArray(new String[systemList.size()]);
		
		int matrixSize = 2;
		int [][] matrix = new int[matrixSize][matrixSize];
		
		for(int i = 0; i < actual.length; i++){
			if(actual[i].equals("F") && system[i].equals("F"))
				matrix[0][0]++;
			else if(actual[i].equals("T") && system[i].equals("F"))
				matrix[1][0]++;
			else if(actual[i].equals("F") && system[i].equals("T"))
				matrix[0][1]++;
			else				// actual is T and system is also T
				matrix[1][1]++;
		}
		
		System.out.println("Matrix is as follows");
		System.out.print(actual.length+"\t"+"N\t"+"P\n");
		for(int i = 0; i < matrixSize; i++){
			if(i == 0)
				System.out.print("N\t");
			else
				System.out.print("P\t");
			
			for(int j = 0; j < matrixSize; j++){
				System.out.print(matrix[i][j]+"\t");
			}
			
			System.out.println("");
		}
	}

}
