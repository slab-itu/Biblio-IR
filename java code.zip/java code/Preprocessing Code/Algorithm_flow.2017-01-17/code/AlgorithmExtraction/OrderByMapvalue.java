package AlgorithmExtraction;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class OrderByMapvalue {

	public static void mapperfunction(Map<String, Double> map,int range,String f) throws IOException{
		//Map<String, Integer> map = new HashMap<String, Integer>();
		/*map.put("java", 20);
        map.put("C++", 45);
        map.put("Java2Novice", 2);
        map.put("Unix", 67);
        map.put("MAC", 26);
        map.put("Why this kolavari", 93);*/
		
		Set<Entry<String, Double>> set = map.entrySet();
		List<Entry<String, Double>> list = new ArrayList<Entry<String, Double>>(set);
		Collections.sort( list, new Comparator<Map.Entry<String, Double>>()
		{
			public int compare( Map.Entry<String, Double> o1, Map.Entry<String, Double> o2 )
			{
				return (o2.getValue()).compareTo( o1.getValue() );
			}
		} );
		int count=0;
		try {
			@SuppressWarnings("resource")
			Writer bw1 = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f),"UTF-8"));
			//BufferedWriter bw1=new bufferedWriter()
			//BufferedWriter bw1 = new BufferedWriter(new FileWriter(f, true));
			//PrintWriter bw1 = new PrintWriter(new BufferedWriter(new FileWriter(f,true)));
			for(Entry<String, Double> entry:list ){
				if(count<range)
				{
					System.out.println(entry.getKey()+" ==== "+entry.getValue());
					
					bw1.write(entry.getKey());
					count++;
					//bw1.write(count);

				}
			
				
			}
			//bw1.flush();
			bw1.close();
		
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}