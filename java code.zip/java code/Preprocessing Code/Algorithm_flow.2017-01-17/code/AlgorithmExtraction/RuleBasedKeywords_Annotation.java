package AlgorithmExtraction;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.lang.Object;
//import org.apache.commons.lang.StringUtils;

import com.sun.xml.internal.ws.util.StringUtils;

public class RuleBasedKeywords_Annotation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//File folder = new File("pseudocode_and_sbs/dataset Complete");
		File folder = new File("pseudocode_and_sbs/complexity dataset");
		File[] listOfFiles = folder.listFiles();

		
		BufferedReader br = null;
		Writer writer = null;
		try {
			//writer = new BufferedWriter(
					//new OutputStreamWriter(new FileOutputStream("Output/RBKeywordsLinenoDatasetAnnotation.csv"), "UTF-8"));
			writer = new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream("Output/RBKeywordsLinenoResultsAnnotation.csv"), "UTF-8"));
			CSVUtils.writeLine(writer, Arrays.asList("File Name", "KeywordsLines"));
			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isFile() && listOfFiles[i].getName().endsWith(".txt")) {
					// System.out.println("File " + listOfFiles[i].getName());

					//String csvFile = "pseudocode_and_sbs/dataset Complete/" + listOfFiles[i].getName();
					String csvFile = "pseudocode_and_sbs/complexity dataset/" + listOfFiles[i].getName();
					br = new BufferedReader(new FileReader(csvFile));

					String line = "";

					String AllLineNumbers = "";
					while ((line = br.readLine()) != null) {

						if (line.contains("|41[::-::]")||line.contains("|44[::-::]")) {
							//String expression = "\\A(FIGURE|Figure|FIG.|Fig.|Algorithm|algorithm|Algo.|algo.)\\s\\d[\\.]?\\d*[:|.|\\|]\\s(\\w+)";
							//String expression = "|2[::-::]";
							String copyLine = line;
							
							line = line.substring(line.indexOf("::]") + 3).trim();
							
										String lineNumber = copyLine.substring(0, copyLine.indexOf("|"));
										System.out.println("In find");
										if(AllLineNumbers.equals(""))
											AllLineNumbers = lineNumber+"";
										else
											AllLineNumbers = AllLineNumbers + "|" + lineNumber;
								
						}
					}
					
					
				if(AllLineNumbers.equals(""))
				AllLineNumbers = "0";
					
					CSVUtils.writeLine(writer, Arrays.asList(listOfFiles[i].getName(), AllLineNumbers));
					
				}
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			if (writer != null) {
				try {
					writer.flush();
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
	}
	

	
}


