package AlgorithmExtraction;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.stream.IntStream;

import com.opencsv.CSVWriter;

import Model.AlgorithmRepresentation;
import Model.PdfDocument;
import PdfSegmentation.PdfExtractor;
import Util.Directory;
import Util.Util;

public class Preprocessing230files {
	public static void main(String args[]){

		// TODO Auto-generated method stub
		List<Integer> num_words_per_line = new ArrayList<Integer>();
		File folder = new File("pseudocode_and_sbs/Without_Ref_abs/");
		File[] listOfFiles = folder.listFiles();
		int positve_lines = 0;
		int neg_lines = 0;
		double word_density=0;
		String CaptionText="";
		String taggedTextFilename="";
		String pdfFilename="";
		int theroshold=8;
		BufferedReader br = null;
		int count_words=0;
		//BufferedReader br1 =null;
		
		try {
			
			//Writer negative_line_writter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("./negative.txt"), "UTF-8"));
			for (int i = 0; i < listOfFiles.length; i++) 
			{
//				writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("output_without_abstract/" + listOfFiles[i].getName()), "UTF-8"));
				DetectPattern.abstract_found = false;
				DetectPattern.ref_section_found = false;
				DetectPattern.ack_section_found = false;
				DetectPattern.intro_section_found = false;
				DetectPattern.background_section_found = false;
				
				
				if (listOfFiles[i].isFile() && listOfFiles[i].getName().endsWith(".txt")) 
				{
					System.out.println("File " + listOfFiles[i].getName());
					try(BufferedReader br1= new BufferedReader(new FileReader(new File("pseudocode_and_sbs/Without_Ref_abs/"+listOfFiles[i].getName())))) {
						for(String line; (line = br1.readLine()) != null; ) {
							
							num_words_per_line.add(Preprocesing.count_words(line));
						}
						
					br1.close();
					//double average_num_word_line = (IntStream.of(num_words_per_line.stream().filter(i -> i != null).mapToInt(i -> i).toArray()).sum())/(num_words_per_line.size());
					//double average_num_word_line=
					String req_file = "pseudocode_and_sbs/Without_Ref_abs/" + listOfFiles[i].getName();
					String req_file2 = "pseudocode_and_sbs/Processed 230/" + listOfFiles[i].getName();
					
					br = new BufferedReader(new FileReader(req_file));
					Writer positive_line_writter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(req_file2), "UTF-8"));
					String line = "";
				    String line2="";
				    boolean do_not_insert = true;
					while ((line = br.readLine()) != null) 
					{
					 if(line.contains("::]")){
						int index=line.indexOf("::]");
						String line_chunk=line.substring(0, index+3);
						line=line.substring(index+3);
						line=line.replaceAll("\\W+", " ");
						//line2=line2.substring(line2.indexOf("::]")).trim();
						line=line_chunk+line;
						int sum=Preprocesing.count_words(line) + (Preprocesing.count_words(line) - 1);
						int count=Preprocesing.count_words(line);
						word_density = (double) count / sum;
						// Decide weather the line should be part of file or not
						if((Preprocesing.count_words(line.substring(line.indexOf("::]") + 3).trim()) >= theroshold && word_density >= 0.5 )){
							//if(
							
							
								//	( 
											//DetectPattern.isBeforeAbstract(line.substring(line.indexOf("::]") + 3).trim())
										//|| DetectPattern.isAfterRef(line.substring(line.indexOf("::]") + 3).trim())
										/*|| DetectPattern.isIncideAck(line.substring(line.indexOf("::]") + 3).trim())
										|| DetectPattern.isIncideIntro(line.substring(line.indexOf("::]") + 3).trim())
										|| DetectPattern.isIncideBackground(line.substring(line.indexOf("::]") + 3).trim())
										|| (DetectPattern.num_words(line.substring(line.indexOf("::]") + 3).trim()) <= DetectPattern.min_word_threshold)*/
									//)
									 
							//)
							{
								  index=line.indexOf("::]");
								line_chunk=line.substring(0, index+3);
								line=line.substring(index+3);
								//line2 = line.substring(line.indexOf("::]") + 3).trim();
								//String line_new=line.substring(line.indexOf("::]") + 3).trim();
								line=line.replaceAll("\\W+", " ");
								//line2=line2.substring(line2.indexOf("::]")).trim();
								//line=line_chunk+line;
								//System.out.println("line 2"+line2);
								positive_line_writter.write(line+"\n");
								positve_lines++;
								do_not_insert = true;
								System.out.println("True lines:" +line);
							}
							
						}
					}
					}
					positive_line_writter.flush();
					positive_line_writter.close();
					
				}
			}
			//positive_line_writter.flush();
			//positive_line_writter.close();
			
			System.out.println("Positive Lines: " + positve_lines);
			System.out.println("Negative Lines: " + neg_lines);
		}
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	
	}
}
