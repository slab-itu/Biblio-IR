package AlgorithmExtraction;
//package AlgorithmExtraction;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;

import org.apache.commons.io.FileUtils;

import Util.Directory;


public class mergefiles {
	
	public static void main(String args[]) throws IOException
	{
		Vector<String> TaggedTextFiles = Directory.listAllFiles("ACL txt/sys/", ".txt", 1);
		//f=
		//BufferedReader br=new BufferedReader(new FileReader(new File(f)));
		BufferedWriter bw=null;
		BufferedReader br=null;
		String fnew=null;
		String writefile=null;
		
		try{
			for(String f: TaggedTextFiles){
				System.out.println("f:"+f);
				fnew = f.substring(f.indexOf("sys/")+4,f.indexOf(".txt")+4).trim();
				File file= new File(f);
				//System.out.println("fnew:"+fnew);
				fnew= fnew.substring(1,fnew.indexOf("_")).trim();
				System.out.println("fnew:"+fnew);
				writefile="ACL txt/SysMerged 1040/"+fnew+".pdf.txt";
		    br=new BufferedReader(new FileReader(new File(f)));
			bw=new BufferedWriter(new FileWriter(writefile,true));
			//new BufferedWriter(new FileWriter(f, true));
			String file1Str = FileUtils.readFileToString(file);
			//String file2Str = FileUtils.readFileToString(file2);
			System.out.println(file1Str);
			bw.write(file1Str);

			// Write the file
			//FileUtils.write(file3, file1Str);
			//FileUtils.write(file3, file2Str, true); // true for append
			//bw.write("hellow1");
			//bw.write("hellow2");
			//bw.write("hellow3");
			//bw.close();

			System.out.println("Data successfully appended at the end of file");
			bw.flush();
			bw.close();
			//br.close();
		}
			bw.flush();
			bw.close();
			br.close();
			
		}
		
		catch(Exception e){
			System.out.println("Exception occurred:");
	    	 e.printStackTrace();
		}
	}

}
