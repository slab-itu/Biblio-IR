package AlgorithmExtraction;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Vector;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.Range;

import weka.classifiers.Classifier;

import MachineLearning.ClassifierFactory;
import Model.TextLine;
import PdfSegmentation.PdfExtractor;
import PdfSegmentation.SectionHeaderClassifier;
import Util.Directory;
import Util.Util;

public class AlgorithmLinker {

	public static void getStatistics(String pcTagDir, String sbsTagDir, String pdfDir, String reportDir)
	{	String report = "";
		Vector<String> pdfFiles = Directory.listAllFiles(pdfDir, ".pdf", 1);
		Classifier sectionHeaderClassifier = ClassifierFactory.loadModel("./models/section_header_randomforest500.model");
		int uniqueAlgorithms = 0;
		int numAllPCs = 0;
		int numAllSBSs = 0;
		int numSinglePCAlgorithms = 0;
		int numSingleSBSAlgorithms = 0;
		for(String pdfFile: pdfFiles)
		{	
			String fileID = Directory.getFileID(pdfFile);
			report+="@@@ Processing file "+fileID+"***********************************\n";
			String pcTagFile = pcTagDir+"/"+fileID+".tagged.txt";
			String sbsTagFile = sbsTagDir+"/"+fileID+".tagged.txt";
			
			//loading data
			Vector<Range<Integer>> sectionRanges = SectionHeaderClassifier.getSectionRanges(pdfFile, sectionHeaderClassifier);
			Vector<Range<Integer>> pcRanges = getTagRange(pcTagFile, 1);
			Vector<Range<Integer>> sbsRanges = getTagRange(sbsTagFile, 11);
			Vector<TextLine> textLines = PdfExtractor.extractTextLinesFromPDF(pdfFile);
			
			//linking
			HashMap<Range<Integer>, HashSet<Range<Integer>>> algorithmMap = new HashMap<Range<Integer>, HashSet<Range<Integer>>>();
			
			for(Range<Integer> section: sectionRanges)
			{	HashSet<Range<Integer>> algoInSection = new HashSet<Range<Integer>>();
				for(Range<Integer> pc: pcRanges)
				{
					if(section.contains(pc.getMinimum())) algoInSection.add(pc);
				}
				
				for(Range<Integer> sbs: sbsRanges)
				{
					if(section.contains(sbs.getMinimum())) algoInSection.add(sbs);
				}
				
				algorithmMap.put(section, algoInSection);
			}
			int numSinglePCs = 0;
			int numSingleSBSs = 0;
			for(HashSet<Range<Integer>> algoGroup: algorithmMap.values())
			{	if(algoGroup.size() >= 1)
				{
					uniqueAlgorithms++;
				}
			
				if(algoGroup.size() == 1)
				{
					Range<Integer> r = (Range<Integer>) algoGroup.toArray()[0];
					if(pcRanges.contains(r)) numSinglePCs++;
					else if(sbsRanges.contains(r)) numSingleSBSs++;
				}
				
				if(algoGroup.size() > 1)
				{	//here just print things out and check
					for(Range<Integer> r: algoGroup)
					{
						for(TextLine tl: textLines)
						{
							if(r.contains(tl.lineNumber))
							{
								report += "["+tl.lineNumber+"]"+tl.text+"\n";
							}
						}
						report+="-----------------------------------\n";
					}
				}
			}
			
			numAllPCs += pcRanges.size();
			numAllSBSs += sbsRanges.size();
			numSinglePCAlgorithms += numSinglePCs;
			numSingleSBSAlgorithms += numSingleSBSs;
		}
		report += "Num All Pseudocodes:"+numAllPCs+" Num All AP:"+numAllSBSs+"\n";
		report += "Num Single-PC algorithms:"+numSinglePCAlgorithms+" Num Single-SBS Algorithms:"+numSingleSBSAlgorithms+"\n";
		report += "Unique Algorithm:"+uniqueAlgorithms+"\n";
		try {
			FileUtils.writeStringToFile(new File(reportDir+"/report.txt"), report);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	/**
	 * get range of consecutive tag in the tagged file
	 * @param tagFilename
	 * @param filterTag
	 * @return
	 */
	public static Vector<Range<Integer>> getTagRange(String taggedFile, int filterTag)
	{
		Vector<Range<Integer>> result = new Vector<Range<Integer>>();
		int curLineNum = 0;
		
	
		try {
			
			List<String> lines = FileUtils.readLines(new File(taggedFile));
			int[] tagVector = new int[lines.size()];
			int[] lineVector = new int[lines.size()];
			for(int i = 0; i < lines.size(); i++)
			{	String line = lines.get(i);
				line = line.trim();
				if(!line.contains("[::-::]")) continue;
				String[] tokens = line.split("\\[::-::\\]");
				//if(tokens.length != 2) continue;
				String[] params = tokens[0].split("\\|");
				lineVector[i] = Integer.parseInt(params[0]);
				curLineNum = lineVector[i];
				if(params.length >= 2 && !params[1].isEmpty())
				{
					tagVector[i] =  Integer.parseInt(params[1]);
				}
			}
			
			//package and return
				for(int i = 0; i < tagVector.length; i++)
				{	
					boolean found = false;
					int start = i;
					int end = i;
					if(tagVector[i] == filterTag)
					{
						found = true;
						start = i;
						
						for(int j = start + 1; j < tagVector.length; j++)
						{
							if(tagVector[j] != filterTag)
							{
								end = j -1;
								break;
							}
						}
					}
					
					if(found)
					{
						Range<Integer> r = Range.between(new Integer(lineVector[start]), new Integer(lineVector[end]));
						result.add(r);
						i = end;
					}
				}
		} catch (Exception e) {
			Util.jout("@@ ERROR around "+taggedFile+":"+curLineNum+"\n");
			e.printStackTrace();
			System.exit(-1);
		}
		
		return result;
	}
	
	public static void main(String[] args)
	{
		getStatistics("./pseudocode_and_sbs", "./pseudocode_and_sbs", "./pseudocode_and_sbs", "./results/algorithm_linking");
	}
}
