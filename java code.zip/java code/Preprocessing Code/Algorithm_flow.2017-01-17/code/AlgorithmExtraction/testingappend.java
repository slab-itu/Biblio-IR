package AlgorithmExtraction;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;


public class testingappend {
	
	public static void main(String args[]) throws IOException
	{
		BufferedWriter bw=null;
		
		try{
			bw=new BufferedWriter(new FileWriter("./testfile.txt",true));
			bw.write("hellow1");
			bw.write("hellow2");
			bw.write("hellow3");
			bw.close();

			System.out.println("Data successfully appended at the end of file");
		}
		
		catch(Exception e){
			System.out.println("Exception occurred:");
	    	 e.printStackTrace();
		}
	}

}
