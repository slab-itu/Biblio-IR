package AlgorithmExtraction;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.lang.Object;
//import org.apache.commons.lang.StringUtils;
import java.nio.file.Files;
import java.nio.file.Paths;

import com.sun.xml.internal.ws.util.StringUtils;

//import test.CSVUtils;

public class Precison_Recall_Calculation{

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		//File folder = new File("pseudocode_and_sbs/dataset Complete");
		File folder = new File("pseudocode_and_sbs/complexity dataset");
		//File folder = new File("sample test data");
		File[] listOfFiles = folder.listFiles();
		
		BufferedReader br = null;
		int index=0;
		int j=0;
		String line_no="";
		//int k=0;
		Writer writer = null;
		String[] lineNumber=new String[listOfFiles.length];
		Integer[] lineno=new Integer[listOfFiles.length];
		//String[] parts={"","","","","","","","","",""};
		ArrayList<String> LineArraySystem=new ArrayList<String>();
		//Integer[] intarray1=new Integer[parts.length];
		ArrayList<String> LineArrayAnnotated=new ArrayList<String>();
		//Integer[] intarray2=new Integer[parts.length];
		String PcLineNo="";
		String line = "";
		//String AllLineNumbers = "";
		//String PcLineNo="";
		//String[] pnLineNo=new String[listOfFiles.length];
		//List<String> CSVLinesSystem = Files.readAllLines(Paths.get("Output/RBLineNumbersDatasetKeywords.csv"));
		//List<String> CSVLinesAnnotated = Files.readAllLines(Paths.get("Output/RBKeywordsLinenoDatasetAnnotation.csv"));
		List<String> CSVLinesSystem = Files.readAllLines(Paths.get("Output/RBLineNumbersResultsKeywords.csv"));
		List<String> CSVLinesAnnotated = Files.readAllLines(Paths.get("Output/RBKeywordsLinenoResultsAnnotation.csv"));
		//APRuleBasedLineNo
		try {
			//writer = new BufferedWriter(
				//	new OutputStreamWriter(new FileOutputStream("Output/CaptionsLineNumbersSample.csv"), "UTF-8"));

			//CSVUtils.writeLine(writer, Arrays.asList("File Name", "Caption Lines"));
			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isFile() && listOfFiles[i].getName().endsWith(".txt")) {
					// System.out.println("File " + listOfFiles[i].getName());

					//String csvFile = "pseudocode_and_sbs/dataset Complete/" + listOfFiles[i].getName();
					String csvFile = "pseudocode_and_sbs/complexity dataset/" + listOfFiles[i].getName();

					
					//String csvFile = "sample test data/" + listOfFiles[i].getName();
					br = new BufferedReader(new FileReader(csvFile));
					
					
						while ((line = br.readLine()) != null) {
							if (line.contains("|[::-::]")){
								String copyLine = line;
								line_no = copyLine.substring(0, copyLine.indexOf("|"));
								//System.out.println("");	
								//lineno[i] = Integer.parseInt(lineNumber[i]);
							}
						}
						lineNumber[i] = line_no;
						System.out.println("");	
						lineno[i] = Integer.parseInt(lineNumber[i]);
						
						//System.out.println("last line NO : "+ lineno );
						//System.out.println("last line NO : "+ lineno[0] );
						//for(j=0;j<=lineno.length ;j++)
							//System.out.println("lineno length:"+ lineno[j]);
						//{ 
						for(int k=0;k <lineno[i] ;k++)
							{
							
							LineArraySystem.add("F");
							LineArrayAnnotated.add("F");
							
							}
						//}
						//System.out.println("Array List size: "+ LineArraySystem.size() );
						//System.out.println("Array List:"+ LineArraySystem );
						//System.out.println("CSV file size:" +CSVLinesSystem.size());
						//System.out.println("iteration:"+ i);
				}
			
			}
			
			for (int k = 1; k < CSVLinesSystem.size(); k=k+1)
			{	
				PcLineNo=CSVLinesSystem.get(k).split(",")[1]; 
				String [] parts = {PcLineNo};
			    Integer[] intarray1 = new Integer[parts.length];
			   // Integer[] intarray2 = new Integer[parts.length];
			    
				if(PcLineNo.indexOf("|")>0)
				{
					//System.out.println("index of: "+PcLineNo.indexOf("|"));
					parts = PcLineNo.split("\\|");
					 
					intarray1 = new Integer[parts.length];
					//intarray2 = new Integer[parts.length];
				}
//				else
//				{ 
//					parts=PcLineNo;
//					//System.out.println("parts:"+ parts[0]);
//				}
				
		       for(int i=0;i<parts.length;i++)
		       {
		    	   //System.out.println("parts:" + parts[i]);
		    	   if(!parts[i].equals("")){
		    	   intarray1[i]=Integer.parseInt(parts[i]);
		    	   }
		           	           
		       }
		       for(int i=0;i<parts.length;i++)
		       {
		    	   if(intarray1[i] != 0){
		    	 
		    	   if(k>0) {
		    	   index=intarray1[i]+lineno[k-1];  
		    	   LineArraySystem.set(index-1, "T" );
		    	   }
		    	   else
		    	   {
		    		   
		    		   index=intarray1[i];  
			    	   LineArraySystem.set(index-1, "T" );   
		    	   }
		    	   }
		       }
		       // for annotated  CSVFile:
		       PcLineNo=CSVLinesAnnotated.get(k).split(",")[1]; 
		       //System.out.println("parts:" + PcLineNo);	
		       parts = new String[]{PcLineNo};
		       Integer[] intarray2 = new Integer[parts.length];
				if(PcLineNo.indexOf("|")>0)
				{
					//System.out.println("index of: "+PcLineNo.indexOf("|"));
					parts = PcLineNo.split("\\|");
					intarray2 = new Integer[parts.length];
				}
				
				
		       for(int i=0;i<parts.length;i++)
		       {
		    	   if(!parts[i].equals("")){
		    	   intarray2[i]=Integer.parseInt(parts[i]);
		    	   }
		         //  System.out.println("parts:" +  parts[i]);	           
		       }
		       for(int i=0;i<parts.length;i++)
		       {
		    	   if(intarray2[i] != 0){
		    	   if(k>0){
		    		   //System.out.println(intarray2[i]);
		    		   //System.out.println(lineno[k-1]);
		    	   index=intarray2[i]+lineno[k-1];  
		    	   LineArrayAnnotated.set(index-1, "T" );
		    	   }
		    	   else
		    	   {
		    		   index=intarray2[i];  
			    	   LineArrayAnnotated.set(index-1, "T" );  
		    	   }
		    	   }
		       }
		      // System.out.println("Array List system:"+ LineArraySystem );
		       //System.out.println("Array List annotated:"+ LineArrayAnnotated );
			}
			   //System.out.println("Array List system:"+ LineArraySystem );
		       //System.out.println("Array List annotated:"+ LineArrayAnnotated );
		       printPrecisionRecallConfusionMatrix( LineArrayAnnotated,LineArraySystem);

		}
				
			catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try { 
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
		// List is an interface and ArrayList is a class, we can assign ArrayList in List
		// List<String> list = new ArrayList<Stirng>(); this is proper way to initialize an ArrayList
		public static void printPrecisionRecallConfusionMatrix(List<String> actualList, List<String> systemList){
			
			String [] actual = actualList.toArray(new String[actualList.size()]);
			String [] system = systemList.toArray(new String[systemList.size()]);
			
			int matrixSize = 2;
			int [][] matrix = new int[matrixSize][matrixSize];
			
			for(int i = 0; i < actual.length; i++){
				if(actual[i].equals("F") && system[i].equals("F"))
					matrix[0][0]++;
				else if(actual[i].equals("T") && system[i].equals("F"))
					matrix[1][0]++;
				else if(actual[i].equals("F") && system[i].equals("T"))
					matrix[0][1]++;
				else				// actual is T and system is also T
					matrix[1][1]++;
			}
			
			System.out.println("Matrix is as follows");
			System.out.print(actual.length+"\t"+"N\t"+"P\n");
			for(int i = 0; i < matrixSize; i++){
				if(i == 0)
					System.out.print("N\t");
				else
					System.out.print("P\t");
				
				for(int j = 0; j < matrixSize; j++){
					System.out.print(matrix[i][j]+"\t");
				}
				
				System.out.println("");
			}
			double a=(matrix[1][1]+matrix[0][1]);
			double precision= matrix[1][1]/a; 
			double b =(matrix[1][1]+matrix[1][0]);
			double recall=matrix[1][1]/b; 
			double Acc=(matrix[0][0]+matrix[1][1]);
			double Acc2=matrix[0][0]+matrix[1][1]+matrix[1][0]+matrix[0][1];
			double accuracy=Acc/Acc2;
			System.out.println("Precision:"+ precision + "	Recall:"+recall+"	Accuracy:"+accuracy);
		}
}


	
	
	

	



