package AlgorithmExtraction;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Util.CsxDBConnector;
import Util.Directory;
import Util.LocalDBConnector;
import Util.SentenceProducer;
import Util.SimpleClock;
import Util.Util;

import com.aliasi.spell.TfIdfDistance;

import com.aliasi.tokenizer.IndoEuropeanTokenizerFactory;
import com.aliasi.tokenizer.TokenizerFactory;

/*
 * Detect the algorithms mentioned in a paper
 * 
 * general input: textfile
 * general output: list of algorithm ids
 * 
 * */
public class AlgorithmUsageDetector {
	String[] algoKeywords = {"algorithm", "method", "procedure"};
	Pattern linkPattern = Pattern.compile("\\[(.*?)\\]");
	Vector<StringPair> stdAlgoList = null; //list of standard algorithm names
	
	public AlgorithmUsageDetector()
	{
		init();
	}
	

	
	
	private void init()
	{
		//load in standard algorithm list from database
		stdAlgoList = new Vector<StringPair>();
		try
		{	LocalDBConnector localDB = new LocalDBConnector();
			
			ResultSet r = localDB.executeQuery("SELECT id, name, alias FROM dictionary");
			while(r.next())
			{
				String algoID = "standard#"+r.getString("id");
				stdAlgoList.add(new StringPair(algoID, r.getString("name")));
				//Util.jout("Loading in: "+r.getString("name")+"|"+r.getString("alias")+"\n");
				String[] aliases = r.getString("alias").split(":");
				for(String alias : aliases)
				{	if(alias.trim().equals("")) continue;
					stdAlgoList.add(new StringPair(algoID, alias));
				}
			}
			
			/*for(StringPair algo:stdAlgoList)
			{
				Util.jout(algo.getFirst()+":"+algo.getSecond()+"\n");
			}*/
			r.close();
			localDB.close();
		}catch(Exception e)
		{	e.printStackTrace();
			Util.errlog(e.toString());
		}
	}
	
	Vector<String> getAlgoIDs(String link, String docID)
	{	Vector<String> algoIDs = new Vector<String>();
		try{
			//TODO
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return algoIDs;
	}
	
	
	
	/**
	 * parse the text file and return the algorithm ids of the algorithms mentioned in the file
	 * 
	 * @param text filename, paper id
	 * @return list of algorithm id
	 */
	private Vector<String> detectMentionedAlgorithms(String textFilename, String citeFilename, String paperid)
	{	Util.jout("@@@ Processing file "+textFilename+"\n");
		
		Vector<String> algoIDs = new Vector<String>();
		try{
			SentenceProducer s = new SentenceProducer(textFilename, 1);
			String sentence = null;
			Vector<String> linksFound = new Vector<String>();	//just vector of numbers (in String format)
			
			
			while((sentence = s.nextSentence()) != null)
			{	Vector<String> keywordsFound = new Vector<String>();
				
				String lSentence = sentence.toLowerCase();
				//check if any algokeyword is in the sentence
				for(String keyword : algoKeywords)
				{
					if(lSentence.contains(keyword))
					{
						keywordsFound.add(keyword);
					}
				}
				
				//if no keywords found, skip to next sentence
				if(keywordsFound.size() == 0) continue;
				
				//check for standard algorithms
				
				//Does not include standard algorithm for now, since noises in std algos
				//dictionary can slow down the performance significantly
				/*for(StringPair sAlgo: stdAlgoList)
				{	
					String algoName = sAlgo.getSecond().toLowerCase();
					//Pattern p = Pattern.compile("(\\s+)"+algoName+"(\\s+)");
					//Util.jout("Quote:"+Pattern.quote(algoName)+"\n");
					//if(Pattern.matches("(\\s)"+Pattern.quote(algoName)+"(\\s)", lSentence))
					if(lSentence.contains(" "+algoName+" "))
					{	//Util.jout("Found:"+algoName+"\n");
						boolean dup  = false;
						for(String algoid: algoIDs)
						{
							if(algoid.equals(sAlgo.getFirst()))
							{
								dup = true;
								break;
							}
						}
						if(!dup) algoIDs.add(sAlgo.getFirst());
					}
				}
				*/
				//check if any links are in the sentence
				Matcher m = linkPattern.matcher(sentence);
				while(m.find()) {
					String[] temp = m.group(1).split(",");
					for(String el :temp)
					{	el = el.trim();
						try{
						Integer.parseInt(el);
						}catch(Exception e)
						{
							break;
						}
						//add non duplicated elements to linksFound
						
						boolean dup = false;
						for(String exEl : linksFound)
						{
							if(exEl.equals(el)) dup = true;break;
						}
						
						if(!dup) linksFound.add(el);
					}
				}
				
				/*
				if(keywordsFound.size() > 0 && linksFound.size() > 0)
				{
					Util.jout("###"+sentence+"\n");
					Util.jout("#Keywords: ");
					for(String k: keywordsFound)
					{
						Util.jout(k+"|");
					}
					
					Util.jout("\n#Links: ");
					for(String k: linksFound)
					{
						Util.jout(k+"|");
					}
					
					Util.jout("\n#Names: ");
					for(String k: namesFound)
					{
						Util.jout(k+"|");
					}
					Util.jout("\n\n");
					
				}
				*/
				
				
			}
			
			//now we have a list of citation numbers whose papers propose some algorithm used in this document
			//parse through the citation file and get the citation text			
			String citeText = "";
			try
			{	
				//check if citation file exists
				File file=new File(citeFilename);
				if(!file.exists())
				{
					Util.log("Cannot find cite file "+citeFilename+"\n");
					return algoIDs;
				}
				
				BufferedReader reader = new BufferedReader(new FileReader(citeFilename));
				String line = "";
				while((line = reader.readLine()) != null)
				{
					citeText += line.trim()+" ";
				}
				
				citeText += "["; //specify end of string
				reader.close();
			}catch(FileNotFoundException fn)
			{	fn.printStackTrace();
				Util.errlog(fn.toString()+citeFilename);
				//treat as if no algorithm is found
				return algoIDs;
				//but do nothing
			}
			catch(Exception e)
			{
				e.printStackTrace();
				Util.errlog(e.toString());
			}
			
			//prepare citation texts
			
			Vector<StringPair> citeClusterMaps = new Vector<StringPair>();
			
			try
			{
				CsxDBConnector csxdb = new CsxDBConnector();
				ResultSet r = csxdb.executeQuery("SELECT cluster, raw FROM citations WHERE paperid = '"+paperid+"';");
				while(r.next())
				{
					citeClusterMaps.add(new StringPair(r.getString("cluster"), r.getString("raw")));
				}
				csxdb.close();
			}catch(Exception e)
			{
				e.printStackTrace();
				Util.errlog(e.toString());
			}
			
			
			//get list of cluster numbers
			Vector<String> clusters = new Vector<String>();

			//initialize TFIDF
			TokenizerFactory tokenizerFactory = IndoEuropeanTokenizerFactory.INSTANCE;
	        TfIdfDistance tfIdf = new TfIdfDistance(tokenizerFactory);
	        for (StringPair sp : citeClusterMaps)
	        {	tfIdf.handle(sp.getSecond());
	        }
	        tfIdf.handle(citeText);
			
			for(String citeNumber : linksFound)
			{	Pattern p = Pattern.compile("\\[(\\s*)"+citeNumber+"(\\s*)\\]([^\\[]*)");
				
				Matcher m = p.matcher(citeText);
				//Util.jout("@Link: "+citeNumber+"\n");
				while(m.find()) {
					String temp = m.group(3).trim();
					//Util.jout("@Cite: "+temp+"\n");
					
					//calculating TF-IDF score and pick the one with the highest score
					double[] tfidfDistances = new double[citeClusterMaps.size()];
					
					for(int i = 0; i < citeClusterMaps.size(); i++)
					{	
						tfidfDistances[i] = tfIdf.distance(temp,citeClusterMaps.elementAt(i).getSecond());
					}
					
					//pick the citation with smallest tfidf distance
					double smallestDist = 10.0;
					int index = -1;
					for(int i = 0; i < tfidfDistances.length; i++)
					{	
						if(tfidfDistances[i] < smallestDist) 
						{	smallestDist = tfidfDistances[i];
							index = i;
						}
					}
					
					//now we get the cluster id
					boolean dup = false;
					for(String clusterid:clusters)
					{
						if(clusterid.equals(citeClusterMaps.elementAt(index).getFirst()))
						{
							dup = true;break;
						}
					}
					
					if(!dup) clusters.add(citeClusterMaps.elementAt(index).getFirst());
					
					break;	//assume one link matches one citation
				}
				//Util.jout("\n");
				//now query the citation text to get the cluster id
				
			}
			
			/*Util.jout("Selected Cluster IDs:");
			for(String cid:clusters)
			{
				Util.jout(cid+"|");
			}
			Util.jout("\n");
			*/
			
			//get algorithm IDs
			
			
			CsxDBConnector csxdb = new CsxDBConnector();
			for(String cid:clusters)
			{	//filter out cluster 0
				if(cid.equals("0")) continue;
				
				//Does not try to see if the actual algorithms exist for now
				/*
				Vector<String> algoListInCluster = new Vector<String>();
				if(pathToSumitAlgoDir != null)
				{	ResultSet r = csxdb.executeQuery("SELECT id FROM papers where cluster = "+cid+";");
					while(r.next())
					{
						Vector<String> algoListInDoc = AlgorithmDictionary.getAlgoIDFromDocID(r.getString("id"), pathToSumitAlgoDir);
						algoListInCluster.addAll(algoListInDoc);
						
					}
					r.close();
				}
				*/
				//if this cluster doesnot have any algorithm at all , create a place holder for this algorithm
				
				String ghostID = "candidate#"+cid;
				algoIDs.add(ghostID);
				
				//else algoIDs.addAll(algoListInCluster);
				
			}
			csxdb.close();
			
			
			/*
			Util.jout("Algorithms used in this paper:\n");
			for(String algoid : algoIDs)
			{
				Util.jout(algoid+"\n");
			}
			*/
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return algoIDs;		
	}
	
	public static HashMap<SwappableStringPair, EdgeInfo>loadEdgeFiles(Vector<String> edgeFilenames)
	{
		HashMap<SwappableStringPair, EdgeInfo> edgeMap = new HashMap<SwappableStringPair, EdgeInfo>();
		try{
			for(String edgeFilename: edgeFilenames)
			{
				Util.jout("Loading in Edge File "+edgeFilename+"\n");
			
				BufferedReader eReader = new BufferedReader(new FileReader(edgeFilename));
				String line = "";
				String nodea = "";
				String nodeb = "";
				int weight = 0;
				Vector<String> paperids = null; 
				while((line = eReader.readLine()) != null)
				{	line = line.trim();
					if(line.equals("")) continue;
					if(line.startsWith("[EDGE]"))
					{	nodea = null;
						nodeb = null;
						weight = -1;
						paperids = null;
						line = line.replace("[EDGE]", "");
						nodea = line.split(":")[1];
						nodeb = line.split(":")[2];
					}
					else if(line.startsWith("[WEIGHT]"))
					{
						line = line.replace("[WEIGHT]", "");
						weight = Integer.parseInt(line.trim());
					}
					else if(line.startsWith("[PAPERIDS]"))
					{
						line = line.replace("[PAPERIDS]", "");
						String[] tokens = line.split(":");
						paperids = new Vector<String>();
						for(String token : tokens)
						{	
							token = token.trim();
							if(!token.isEmpty())
							{
								paperids.add(token);
							}
						}
					}
					else if(line.startsWith("[/EDGE]"))
					{	
						if(nodea == null || nodeb == null || weight == -1 || paperids == null)
						{
							Util.errlog("Something is wrong with your preloading edge file\n");
							System.exit(-1);
						}
						SwappableStringPair key = new SwappableStringPair(nodea, nodeb);
						//check for duplicate edge
						EdgeInfo ei = edgeMap.get(key);
						if(ei != null)
							//edge exists
						{
							ei.paperids = combineLists(ei.paperids, paperids);
							ei.weight = ei.paperids.size();
						}
						else
						{
							edgeMap.put(key, new EdgeInfo(weight, paperids));
						}
						
					}
					else
					{
						//there's an unknown field, raise a flag
						Util.errlog("Unknown field in the preloading edge file: "+line+"\n");
						System.exit(-1);
					}
					
				}
				
				eReader.close();
			
			}
		}catch(Exception e)
		{
			e.printStackTrace();
			Util.errlog(e.toString());
		}
		
		return edgeMap;
	}
	

	
	public static void updateEdgeDB(HashMap<SwappableStringPair, EdgeInfo> edgeMap)
	//read the edge files and update edges in the database
	{
		//update edge weights
		/*LocalDBConnector localDB = new LocalDBConnector();
		for(int i = 0;i < algoIDs.size() -1;i++)
		{	String nodea = algoIDs.elementAt(i);
			for(int j = i+1; j < algoIDs.size(); j++)
			{	String nodeb = algoIDs.elementAt(j);
				ResultSet r = localDB.executeQuery("SELECT * FROM cooccurrence_graph WHERE (nodea = '"+nodea+"' AND nodeb = '"+nodeb+"') OR (nodea = '"+nodeb+"' AND nodeb = '"+nodea+"');");
				int count = 0;
				assert(count <= 1);
				
				String use_paper_id = "";
				int use_paper_count = 0;
				double weight = 0;
				String id = "";
				
				while(r.next())
				{	id = r.getString("id");
					weight = r.getDouble("weight");
					use_paper_id = r.getString("use_paper_id");
					use_paper_count = r.getInt("use_paper_count");
					count++;
				}
				
				use_paper_id = AlgorithmDictionary.concatText(use_paper_id, paperid);
				use_paper_count = use_paper_id.split(":").length;
				
				//current weight scheme is the number of papers nodea and nodeb are comentioned
				weight = (double)use_paper_count;
				if(count > 0) // edge exists
				{
					//update
					String query = "UPDATE cooccurrence_graph SET ";
					query += "weight = "+weight+", ";
					query += "use_paper_id = '"+use_paper_id+"', ";
					query += "use_paper_count = "+use_paper_count+" ";
					query += "WHERE id = "+id+";";
					localDB.executeUpdate(query);
				}
				else
				{
					//insert an edge
					String query = "INSERT INTO cooccurrence_graph (nodea, nodeb, weight, use_paper_id, use_paper_count) VALUES ";
					query+="('"+nodea+"', '"+nodeb+"', "+weight+", '"+use_paper_id+"', "+use_paper_count+");";
					localDB.executeUpdate(query);
				}
				
				r.close();
			}
		}
		
		*/
		
		
		
		
		
		//just copy in-memory table to the db table
		LocalDBConnector localDB = new LocalDBConnector();
		try{
			 Iterator<SwappableStringPair> keys = edgeMap.keySet().iterator();
			 String nodea = "";
			 String nodeb = "";
			 SwappableStringPair key = null;
			 EdgeInfo einfo = null;
			 String paperids=  null;
			 String query = null;
			 while(keys.hasNext())
			 {
				 key = (SwappableStringPair)keys.next();
				 nodea = key.getFirst();
				 nodeb = key.getSecond();
				 einfo = edgeMap.get(key);
				 paperids = "";
				 for(String paperid:einfo.paperids)
				 {
					 paperids += paperid+" ";
				 }
				 paperids = paperids.trim().replace(' ', ':');
				 
				 //insert into db
				query  = "INSERT INTO cooccurrence_graph (nodea, nodeb, weight, use_paper_id) VALUES ";
				query+="('"+nodea+"', '"+nodeb+"', "+einfo.weight+", '"+paperids+"');";
				localDB.executeUpdate(query);
			 }
		}catch(Exception e)
		{
			e.printStackTrace();
			Util.errlog(e.toString());
		}
		localDB.close();
	}
	
	/**
	 * pathToSubdir is the path to the repository of the citeseerxDocument
	 * i.e. /opt/data/repositories/rep1/10/1/1
	 * 
	 * This method iteratively reads all the documents, 
	 * detects algorithm mentioned in each document, and creates edges or increases
	 * the weight of existing edges of comentioned algorithms
	 * 
	 * The graph structure is maintained in the database
	 * 
	 * @param pathToSubdir
	 */
	private void genAlgorithmOccurenceGraph(String subdirListFilename, String pathToDocRepo, String existingEdgeFile)
	{	Util.jout("@@@ Cooccurence Graph Generator is running\n");
		
	
		Vector<String> level1SubDirs = new Vector<String>();
		try{
			BufferedReader reader = new BufferedReader(new FileReader(subdirListFilename));
			String child = "";
			while((child = reader.readLine()) != null)
			{	child = child.trim();
				if(child.isEmpty()) continue;
				String l1path = pathToDocRepo+"/"+child;
				File f = new File(l1path);
				if(f.isDirectory()) level1SubDirs.add(l1path);
			}
			reader.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		HashMap<SwappableStringPair, EdgeInfo> edgeMap = new HashMap<SwappableStringPair, EdgeInfo>();
		
		//initialize initial in memory edge table
		if(existingEdgeFile != null)
		{	Vector<String> edgeFile = new Vector<String>();
			edgeFile.add(existingEdgeFile);
			edgeMap = loadEdgeFiles(edgeFile);
		}
		
		
		for(String level1SubDir: level1SubDirs) //repo level
		{	
			//create in-memory edge database
			
			Util.log("Working on "+level1SubDir+"\n");
			SimpleClock clock = new SimpleClock();
			clock.start();
			Vector<String> docDirs = new Vector<String>();
			
			try{
				File dir = new File(level1SubDir);
				String[] children = dir.list();
				for(String child: children)
				{	String docDirPath = level1SubDir+"/"+child;
					File f = new File(docDirPath);
					if(f.isDirectory()) docDirs.add(docDirPath);
				}
				
			}catch(Exception e)
			{
				e.printStackTrace();
			}
			
			//now we get list of doc dirs
			
			for(String docDirPath: docDirs)	//file level
			{
				//process each document
				Vector<String> components = Directory.listAllFiles(docDirPath, "", 1);
				String bodyFile = "";
				String citeFile = "";
				String docID = "";
				//String algoRepo = pathToSumitAlgoDir;
				for(String component: components)
				{
					if(component.endsWith(".body")) bodyFile = component;
					else if(component.endsWith(".cite")) citeFile = component;
					else if(component.endsWith(".pdf")) docID = Directory.getFileID(Directory.getFileName(component));
				}
				
				Vector<String> algoIDs = this.detectMentionedAlgorithms(bodyFile, citeFile, docID);
				//update in-memory table of edges
				String nodea = "";
				String nodeb = "";
				for(int i = 0; i < algoIDs.size() - 1; i ++)
				{	nodea = algoIDs.elementAt(i);
					for(int j = i+1; j < algoIDs.size(); j++)
					{	nodeb = algoIDs.elementAt(j);
						SwappableStringPair key = new SwappableStringPair(nodea, nodeb);
						EdgeInfo einfo = edgeMap.get(key);
						
						if(einfo == null)//new edge
						{	einfo = new EdgeInfo();
							einfo.weight = 1;
							einfo.paperids.add(docID);
							edgeMap.put(new SwappableStringPair(nodea, nodeb), einfo);
						}
						else	//update in memory edge table 
						{
							einfo.paperids = addDistinctElement(einfo.paperids, docID);
							einfo.weight = einfo.paperids.size();
							edgeMap.put(key, einfo);
						}
					}
				}
			}//end subdir level
			clock.stop();
			Util.log("Time used for subdir "+level1SubDir+" = "+clock.getTime()+"\n");
			backupEdgeFile("./temp/edges_up_to"+level1SubDir.replace('/', '_')+".txt", edgeMap);
		}//end repo level
		
		//update the actual edge db
		updateEdgeDB(edgeMap);
	}
	
	public static void backupEdgeFile(String outfile, HashMap<SwappableStringPair, EdgeInfo> edgeMap)
	{	Util.log("Writing backup edge file "+outfile+"\n");
		try
		{
			BufferedWriter writer = new BufferedWriter(new FileWriter(outfile));
			Iterator<SwappableStringPair> keys = edgeMap.keySet().iterator();
			 String nodea = "";
			 String nodeb = "";
			 SwappableStringPair key = null;
			 EdgeInfo einfo = null;
			 String paperids=  null;
			 int edgeCount = 0;
			 while(keys.hasNext())
			 {
				 key = (SwappableStringPair)keys.next();
				 nodea = key.getFirst();
				 nodeb = key.getSecond();
				 einfo = edgeMap.get(key);
				 paperids = "";
				 for(String paperid:einfo.paperids)
				 {
					 paperids += paperid+" ";
				 }
				 paperids = paperids.trim().replace(' ', ':');
				 edgeCount++;
				 writer.write("[EDGE]"+edgeCount+":"+nodea+":"+nodeb+"\n");
				 writer.write("[WEIGHT]"+einfo.weight+"\n");
				 writer.write("[PAPERIDS]"+paperids+"\n");
				 writer.write("[/EDGE]\n");
				 
			 }
			writer.close();
		}catch(Exception e)
		{
			e.printStackTrace();
			Util.errlog(e.toString()+"\n");		
		}
		Util.jout("Done Writing backup.\n");
	}
	
	//in case the graph generated process is killed, this method is used to reverse the changes
	public static void dropEdgesGeneratedFromSubdir(String subDir)
	{
		LocalDBConnector localdb = new LocalDBConnector();
		try{
			ResultSet r = localdb.executeQuery("SELECT * FROM cooccurrence_graph WHERE use_paper_id LIKE '%10.1.1."+subDir+".%';");
			String use_paper_id = "";
			int use_paper_count = -1;
			double weight = -1;
			String subdirDetected = "";
			String edgeID = "";
			while(r.next())
			{
				use_paper_id = r.getString("use_paper_id");
				edgeID = r.getString("id");
				if(use_paper_id.trim().equals("")) continue;
				String[] paperids = use_paper_id.split(":");
				use_paper_id = "";
				
				int count = 0;
				for(String paperid:paperids)
				{	paperid = paperid.trim();
					
					if(paperid.isEmpty()) continue;
					
					subdirDetected = paperid.split("\\.")[3];
					if(!subdirDetected.equals(subDir))
					{
						use_paper_id+=paperid+" ";
						count++;
					}
				}
				use_paper_id = use_paper_id.trim().replace(' ', ':');
				use_paper_count = count;
				weight = (double)use_paper_count;
				
				//update edge
				//update
				String query = "UPDATE cooccurrence_graph SET ";
				query += "weight = "+weight+", ";
				query += "use_paper_id = '"+use_paper_id+"', ";
				query += "use_paper_count = "+use_paper_count+" ";
				query += "WHERE id = "+edgeID+";";
				localdb.executeUpdate(query);
				
			}
			r.close();
		}catch(Exception e)
		{
			e.printStackTrace();
			Util.errlog(e.toString());
		}
		
		//delete 0 weight edges
		String query = "DELETE FROM cooccurrence_graph WHERE use_paper_count = 0;";
		localdb.executeUpdate(query);
		localdb.close();
	}
	
	public static Vector<String> combineLists(Vector<String> x, Vector<String> y)
	//combine two list where duplicated elements are removed
	{	Vector<String> result = new Vector<String>();
		boolean dup = false;
		for(String xx:x)
		{	dup = false;
			for(String r:result)
			{
				if(r.equals(xx))
				{
					dup  =true;
					break;
				}
			}
			if(!dup)result.add(xx);
		}
		
		for(String yy:x)
		{	dup = false;
			for(String r:result)
			{
				if(r.equals(yy))
				{
					dup  =true;
					break;
				}
			}
			if(!dup)result.add(yy);
		}
		
		return result;
	}
	
	public static Vector<String> addDistinctElement(Vector<String> x, String y)
	{	boolean dup  =false;
		for(String xx:x)
		{
			if(xx.equals(y))
			{
				dup = true;break;
			}
		}
		if(!dup) x.add(y);
		return x;
	}
	
	public static void main(String args[])
	{
		AlgorithmUsageDetector algodetector = new AlgorithmUsageDetector();
		assert(args.length > 1);
		
		if(args[0].equalsIgnoreCase("dropedges"))
		{	String subdirfile = args[1];
			try{
				BufferedReader reader = new BufferedReader(new FileReader(subdirfile));
				String line = "";
				while((line = reader.readLine()) != null)
				{
					line = line.trim();
					if(line.isEmpty()) continue;
					AlgorithmUsageDetector.dropEdgesGeneratedFromSubdir(line);
				}
				
				reader.close();
			
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(args[0].equalsIgnoreCase("gencograph"))
		{	 
			algodetector.genAlgorithmOccurenceGraph(args[1], args[2], null);
		}
		else if(args[0].equalsIgnoreCase("continue_gencograph"))
		{	 
			algodetector.genAlgorithmOccurenceGraph(args[1], args[2], args[3]);
		}
		else if(args[0].equalsIgnoreCase("import_cograph"))
		{	
			Vector<String> edgeFilenames = new Vector<String>();
			for(int i = 1; i < args.length; i++)
			{
				edgeFilenames.add(args[i]);
			}
			AlgorithmUsageDetector.updateEdgeDB(AlgorithmUsageDetector.loadEdgeFiles(edgeFilenames));
		}
		
		//algodetector.genAlgorithmOccurenceGraph("/opt/data/repositories/rep1/10/1/1", null);
		//algodetector.genAlgorithmOccurenceGraph("/opt/data/repositories/rep1/10/1/1");
		//algodetector.detectMentionedAlgorithms("/opt/data/repositories/rep1/10/1/1/23/2084/10.1.1.23.2084.body", "/opt/data/repositories/rep1/10/1/1/23/2084/10.1.1.23.2084.cite", "10.1.1.23.2084", "");
		//algodetector.detectMentionedAlgorithms("sample/2084/10.1.1.23.2084.body", "sample/2084/10.1.1.23.2084.cite", "10.1.1.23.2084", "");
		//algodetector.detectMentionedAlgorithms("sample/10.1.1.3.4505.txt", "sample/10.1.1.3.4505.txt", "10.1.1.3.4505");
		//algodetector.detectMentionedAlgorithms("sample/10.1.1.3.8389.txt", "sample/10.1.1.3.8389.txt", "10.1.1.3.8389");
		//algodetector.detectMentionedAlgorithms("sample/10.1.1.7.7946.txt", "sample/10.1.1.7.7946.txt", "10.1.1.7.7946");
	}
}

class EdgeInfo
{
	int weight;
	Vector<String> paperids = new Vector<String>();
	public EdgeInfo(int w, Vector<String> p)
	{
		weight = w;
		paperids = p;
	}
	public EdgeInfo()
	{
	}
	
}

class StringPair
{
	String A;
	String B;
	public StringPair(String _A, String _B)
	{
		A = _A;
		B = _B;
	}
	
	String getFirst(){return A;};
	String getSecond(){return B;}
}

class SwappableStringPair
{
	String A;
	String B;
	public SwappableStringPair(String _A, String _B)
	{
		A = _A;
		B = _B;
	}
	
	@Override
	public boolean equals(Object x)
	{
		String xa = ((SwappableStringPair)x).getFirst();
		String xb = ((SwappableStringPair)x).getSecond();
		
		if((this.A.equals(xa) && this.B.equals(xb)) || ((this.A.equals(xb) && this.B.equals(xa)))) return true;
		return false;
	}
	
	@Override
	public int hashCode()
	{
		return A.hashCode()+B.hashCode();
	}
	
	String getFirst(){return A;};
	String getSecond(){return B;}
}