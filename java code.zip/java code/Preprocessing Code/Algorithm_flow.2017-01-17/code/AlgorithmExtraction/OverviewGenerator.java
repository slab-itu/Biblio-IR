package AlgorithmExtraction;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import Model.DocumentNode;
import Model.HierarchicalDocumentStructure;
import Model.PdfDocument;
import Model.Proposal;
import Model.DocumentNode.StdSection;
import PdfSegmentation.DocumentSegmentator;
import PdfSegmentation.PdfExtractor;
import Util.ConfigReader;
import Util.DocumentUtil;
import Util.Util;



/**
 * This class is meant to generate overview of an algorithm from a paper
 *
 */
public class OverviewGenerator {
	static boolean libinit = false;
	public static HashSet<String >stopwordList = new HashSet<String>();
	static int MAX_N_GRAMS = 5;
	static int pre_window = 2;
	static int post_window = 2;
	
	private static void initLib()
	{	
		//Loading stopwords
		ConfigReader stopwordReader = new ConfigReader("./configs/stopwords.txt");
		String[] tokens = stopwordReader.getValue("stopwords").split("\\|");
		
		for(String word:tokens)
		{	word = word.trim();
			if(!word.isEmpty()) stopwordList.add(word);
		}
	}
	
	public OverviewGenerator()
	{
		
	}
	
	/**
	 * fetches and displays sample
	 * @param textFilename
	 */
	public static void fetchSampleContext(String pdfFilename)
	{	if(!libinit) initLib();
		HashMap<Integer, Vector<String> > ngrams = new HashMap<Integer, Vector<String> >();
		
		try{
		PdfDocument pdfDoc = PdfExtractor.getPdfDocument(pdfFilename);
		
		HierarchicalDocumentStructure hd = pdfDoc.hd;
		
		Vector<Proposal> props = new Vector<Proposal>();
		//first, get proposal sentences
		props = Proposal.extractProposalsFromFile(pdfDoc, "regex");
		
		//get n-grams from proposal sentences in ABS
		for(Proposal prop: props)
		{
			if(prop.getSection() == DocumentNode.StdSection.HDR 
					|| prop.getSection() == DocumentNode.StdSection.ABS)
			{
				Util.jout("Sentence: "+prop.getPropSentence()+"\n");
				//remove stop words and full stop from sentence
				String temp = prop.getPropSentence();
				
				Vector<String> tokens = DocumentUtil.getTokens(temp);
				
				for(String sword: stopwordList)
				{	for(int i = 0; i < tokens.size(); i++)
					{	
						if(tokens.elementAt(i).equalsIgnoreCase(sword))
						{	tokens.remove(i);
							i--;
						}
					}
				}
				temp ="";
				for(String token: tokens)
				{
					temp += token+" "; 
				}
				temp = temp.trim();
				Util.jout("Cleaned: "+temp+"\n");
				
				//obtain n-grams
				for(int i = 1; i <= MAX_N_GRAMS; i++)
				{	Vector<String> tempGrams = new Vector<String>();
					for(int j = 0; j < tokens.size(); j++)
					{	String tempGram = "";
						if(j+i > tokens.size()) continue;
						for(int k = 0; k < i; k++)
						{
							tempGram += tokens.elementAt(j+k) + " "; 
						}
						tempGram = tempGram.trim();
						tempGrams.add(tempGram);
					}
					ngrams.put(new Integer(i), tempGrams);
				}
				
				//display ngram
				for(int i = 1; i<= MAX_N_GRAMS; i++)
				{	Util.jout("["+i+"]");
					for(String gram: ngrams.get(new Integer(i)))
					{
						Util.jout(gram+"|");
					}
					Util.jout("\n");
				}
			}
		} //done extracting n-grams
		
		//get all related sentences
		Vector<String> sentences = hd.getBodySentences();
		
		//map Ngram number to index
		HashMap<Integer, HashSet<Integer>> usefulSentences = new HashMap<Integer, HashSet<Integer>>();
		HashSet<Integer> accIndexSet = new HashSet<Integer>(); 
		for(int i = MAX_N_GRAMS; i >= 1; i--)
		{
			Vector<String> grams = ngrams.get(new Integer(i));
			HashSet<Integer> indexSet = new HashSet<Integer>();
			for(int j = 0; j < sentences.size(); j++)
			{
				String s = sentences.elementAt(j);
				//exclude proposal sentences
				boolean isPropSent = false;
				for(Proposal prop: props)
				{
					if(s.equals(prop.getPropSentence()))
					{
						isPropSent = true;
						break;
					}
				}
				if(isPropSent) continue;
				
				for(String gram: grams)
				{
					if(DocumentUtil.tokenizingContain(s, gram))
					{
						//mark the sentence
						s = s.replace(gram, "{*"+i+"* "+gram+" }");
						sentences.remove(j);
						sentences.add(j, s);
						indexSet.add(new Integer(j));
					}
				}
			}
			
			//remove overlap indexSet
			indexSet.removeAll(accIndexSet);
			accIndexSet.addAll(indexSet);
			
			usefulSentences.put(new Integer(i), indexSet);
		}
		
		//display
		Util.jout("Useful Sentences:\n");
		for(int i = 0; i < sentences.size(); i++)
		{	Integer index = new Integer(i);
			for(int j = MAX_N_GRAMS; j >= 1; j--)
			{	HashSet<Integer> indexSet = usefulSentences.get(new Integer(j));
				//if(indexSet == null) continue;
				if(indexSet.contains(index))
				{
					
					Util.jout("\n");
					//print pre sentences
					/*int preStartIndex = 0;
					if(i - pre_window > 0) preStartIndex = i - pre_window;
					for(int k = preStartIndex; k < preStartIndex+pre_window; k++)
					{
						Util.jout("[pre]"+sentences.elementAt(k)+"\n");
					}
					*/
					Util.jout("["+j+"]"+sentences.elementAt(i)+"\n");
					//print post sentences
					/*int postEndIndex = i+post_window;
					if(postEndIndex >= sentences.size()) postEndIndex = sentences.size()-1;
					for(int k = i+1; k <= postEndIndex; k++)
					{
						Util.jout("[post]"+sentences.elementAt(k)+"\n");
					}*/
				}
			}
		}
		
		}catch (Exception e)
		{}
		
		
	}
	
	public static void main(String[] args)
	{
		fetchSampleContext("./sample/10.1.1.3.6919.pdf");
		//fetchSampleContext("./sample/10.1.1.1.3799.txt");
	}
	
}
