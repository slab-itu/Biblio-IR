package AlgorithmExtraction;

import java.awt.Color; 
import java.util.ArrayList; 
import java.util.HashMap; 
import java.util.Map; 
 
import javax.swing.BorderFactory; 
import javax.swing.UIManager; 
import javax.swing.plaf.BorderUIResource; 
import javax.swing.plaf.ColorUIResource; 
 
//import ir.ai.algorithms.*; 
//import ir.ai.gui.DisplayTable; 
//import ir.ai.gui.FileChooser; 
//import ir.ai.util.DocObject; 
//import ir.ai.util.DocParser; 
//import ir.ai.util.Util; 
 
public class Main { 
 
 /*private String[] keywords = new String[] { "Adams", "Lincoln", "president", 
   "assassinated president", "great president", "first president", 
   "civil war president", "youngest president", "watergate scandal", 
   "first african american president", "cuban missile crisis", "terrorist attack", "founding father", 
   "death by pneumonia", "budget surplus", "no child left behind", "governor", "poliomyelitis" }; */
 
 private void printResult(Map<String, ArrayList<DocObject>> result, 
   String algorithm,String[] keywords) { 
 
  String[][] tableValues = new String[20][keywords.length]; 
  String[][] scores = new String[20][keywords.length]; 
 
  for (int j = 0; j < keywords.length; j++) { 
   int i = 0; 
   String keyword = keywords[j].toLowerCase(); 
   for (DocObject document : result.get(keyword)) { 
    tableValues[i][j] = document.getName(); 
    scores[i][j] = String.valueOf(document.getScore()); 
    i++; 
    tableValues[i][j] = String.format("%.3f", document.getScore()); 
    scores[i][j] = ""; 
    i++; 
   } 
  } 
 
  Display(tableValues, algorithm, keywords, scores); 
//  table.setVisible(true); 
 } 
 public void Display(String[][] tableValues, String algorithm,String[] keyword,String[][] scores)
 {
	 for(int i=0;i<=tableValues.length;i++)
	 {
		 for(int j=0;j<tableValues[0].length;j++)
		 {
			 System.out.println("table values: "+(String) tableValues[i][j]+ "score: "+scores[i][j]+"algorithm: "+algorithm+ "Keywords: "+keyword[i]);
		 }
	 }
	 
 }
 public void runAlgorithmFor(String algorithm, String corpus,String[] keywords) { 
 
	 
  Map<String, ArrayList<DocObject>> result = new HashMap<>(); 
  DocParser parser = new DocParser(); 
  ArrayList<DocObject> docList = parser.getDocList(corpus); 
  Map<String, Integer> docFrequencyMap = Util 
    .retrieveDocFrequency(docList); 
 
  switch (algorithm.toLowerCase()) { 
  case "bm25": 
   BM25 bm25 = new BM25(keywords, docList, docFrequencyMap); 
   result = bm25.getResults(); 
   break; 
//  case "skip bi-grams": 
//   SkipBiGram skipBiGram = new SkipBiGram(keywords, docList); 
//   result = skipBiGram.getResults(); 
//   break; 
//  case "n-grams": 
//   NGram nGram = new NGram(keywords, docList); 
//   result = nGram.getResults(); 
//   break; 
//  case "passage term matching": 
//   PassageTermMatching passageTermMatching = new PassageTermMatching( 
//     keywords, docList, docFrequencyMap); 
//   result = passageTermMatching.getResults(); 
//   break; 
//  case "textual alignment": 
//   TextualAlignment textualAlignment = new TextualAlignment(keywords, 
//     docList, docFrequencyMap); 
//   result = textualAlignment.getResults(); 
//   break; 
  default: 
   System.out.println("Unknown Algorithm"); 
   break; 
  } 
  printResult(result, algorithm,keywords); 
 } 
 
 public static void main(String[] args) { 
 
	/*Main m=new Main();
	Map<String, ArrayList<DocObject>> result = new HashMap<>();
	String[] keywords={"hellow","this"};
	m.runAlgorithmFor("bm25", "./pseudocode_and_sbs/Prcessed",keywords);
	*/
  // try { 
  // UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); 
  // UIManager.put("Table.background", Color.BLACK); 
  // UIManager.put("Table.foreground", Color.WHITE); 
  // UIManager.put("Table.alternateRowColor", Color.GRAY); 
  // } 
  // catch (Exception e) { 
  // e.printStackTrace(); 
  // } 
 
  //try { 
   // UIManager.setLookAndFeel("com.seaglasslookandfeel.SeaGlassLookAndFeel"); 
   // for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) 
   // { 
   // if ("Nimbus".equals(info.getName())) { 
   // UIManager.setLookAndFeel(info.getClassName()); 
   // break; 
   // } 
   // } 
   
 
 // FileChooser fc = new FileChooser(new Main()); 
  //fc.setVisible(true); 
 } 
 
}
