package AlgorithmExtraction;

//public class RuleBased_Keywords {

//}
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RuleBased_Keywords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File folder = new File("pseudocode_and_sbs/complexity dataset");
		//File folder = new File("pseudocode_and_sbs/dataset Complete");
		//dataset Complete
		File[] listOfFiles = folder.listFiles();

		BufferedReader br = null;
		Writer writer = null;
		try {
			//writer = new BufferedWriter(
				//	new OutputStreamWriter(new FileOutputStream("Output/RBLineNumbersDatasetKeywords.csv"), "UTF-8"));
			writer = new BufferedWriter(
				new OutputStreamWriter(new FileOutputStream("Output/RBLineNumbersResultsKeywords.csv"), "UTF-8"));
			CSVUtils.writeLine(writer, Arrays.asList("File Name", "KeywordsLines"));
			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isFile() && listOfFiles[i].getName().endsWith(".txt")) {
					// System.out.println("File " + listOfFiles[i].getName());

					//String csvFile = "pseudocode_and_sbs/dataset Complete/" + listOfFiles[i].getName();
					String csvFile = "pseudocode_and_sbs/complexity dataset/" + listOfFiles[i].getName();
					br = new BufferedReader(new FileReader(csvFile));

					String line = "";

					String AllLineNumbers = "";
					while ((line = br.readLine()) != null) {

						if (line.contains("::]")) {
						
							String copyLine = line;
							line = line.substring(line.indexOf("::]") + 3).trim();
							//Pattern p = Pattern.compile(expression);
							//Matcher m = p.matcher(line);
							//if (m.find()) {
								if (indexOfKeyword(line) > 0)
								{
									///int indexOfPreposition = checkPrepositions(line);
									//if(indexOfPreposition < 0 || (indexOfKeyword(line) < indexOfPreposition)){
										String lineNumber = copyLine.substring(0, copyLine.indexOf("|"));
										
										if(AllLineNumbers.equals("")){
											AllLineNumbers = lineNumber+"";}
										else{
											AllLineNumbers = AllLineNumbers + "|" + lineNumber;
									       }
								}
						
							//}
						}
					}
					
					if(AllLineNumbers.equals(""))
						AllLineNumbers = "0";
					
					CSVUtils.writeLine(writer, Arrays.asList(listOfFiles[i].getName(), AllLineNumbers));
					System.out.println("done");
				}
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			if (writer != null) {
				try {
					writer.flush();
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
	}
	
	public static int checkPrepositions(String str){
		String [] prepositions = new String[]{"Above", "about", "across", "against", "along", "among", "around", "at", "Before", "behind", "below", "beneath", "beside", "between", "beyond", "by", "Down", "during", "Except", "For", "from", "In", "inside", "into", "Like", "Near", "Of", "off", "on", "Since", "To", "toward", "through", "Under", "until", "up", "upon", "With", "within"};
		
		for (String word : prepositions) {
		   if (str.indexOf(word) > 0) {
		       return str.indexOf(word);
		   }
		}
		
		return -1;
	}
	
	public static int indexOfKeyword(String str){
		//String [] keywords = new String[]{"Data","Corpus", "Data Set", "Datatset", "DataSet"}; // we can write more keywords here
		//String [] keywords = new String[]{"Complexity","Run time","running time","Running time","Big Oh","O(n)"}; // we can write more keywords here
		String [] keywords = new String[]{"Precision","recall","precision","recall", "SNR", "snr", "fmeasure","fscore","f1","F1","density","Density"}; 
		for (String word : keywords) {
		   if (str.indexOf(word) > 0) {
		       return str.indexOf(word);
		   }
		}
		
		return -1;
	}

}