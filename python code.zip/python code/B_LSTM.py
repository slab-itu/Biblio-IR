import pandas as pd
from keras.models import Model
from keras.layers import Dense, Input, Dropout, MaxPooling1D, Conv1D
from keras.layers import LSTM, Lambda
from keras.layers import TimeDistributed, Bidirectional
from keras.layers.normalization import BatchNormalization
import numpy as np
import tensorflow as tf
import re
import keras.callbacks
import sys
import os
import pandas
import sklearn.metrics as sklm
from keras import backend as K
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import average_precision_score
from sklearn.preprocessing import label_binarize
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_recall_fscore_support
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
import csv



class Metrics(keras.callbacks.Callback):
    def on_train_begin(self, logs={}):
        self.confusion = []
        self.precision = []
        self.recall = []
        self.f1s = []
        self.kappa = []
        self.auc = []

    def on_epoch_end(self, epoch, logs={}):
        score = np.asarray(self.model.predict(self.validation_data[0]))
        predict = np.round(np.asarray(self.model.predict(self.validation_data[0])))
        targ = self.validation_data[1]
	y_test_non_category = [ np.argmax(t) for t in targ ]
	y_predict_non_category = [ np.argmax(t) for t in predict ]
	conf_mat = confusion_matrix(y_test_non_category, y_predict_non_category)
	print("confusion_matrics")
	print(conf_mat)
        #self.auc.append(sklm.roc_auc_score(targ, score))
        self.confusion.append(confusion_matrix(y_test_non_category, y_predict_non_category))
	print("confusion_matrics 2")
	print(self.confusion)
        self.precision.append(precision_score(y_test_non_category, y_predict_non_category,average='weighted'))
        self.recall.append(recall_score(y_test_non_category, y_predict_non_category,average='weighted'))
        
        #self.f1s.append(sklm.f1_score(targ, predict))
        #self.kappa.append(sklm.cohen_kappa_score(targ, predict))
	#precision=precision_score(y_test_non_category, y_predict_non_category,average='weighted')
	#print("precision")
	#print (self.precision)
	#recall=recall_score(y_test_non_category, y_predict_non_category,average='weighted')
	#print("recall")
	#print (self.recall)
	#print("recall" +recall)
		

        return



def binarize(x, sz=71):
    return tf.to_float(tf.one_hot(x, sz, on_value=1, off_value=0, axis=-1))


def binarize_outshape(in_shape):
    return in_shape[0], in_shape[1], 71


def striphtml(html):
   # p = re.compile(r'<.*?>')
    return html    #return p.sub('\s+', ' ', html)


def clean(s):
    return s
# re.sub(r'[^\x00-\x7f]', r'', s)


# record history of training
class LossHistory(keras.callbacks.Callback):
    def on_train_begin(self, logs={}):
        self.losses = []
        self.accuracies = []

    def on_batch_end(self, batch, logs={}):
        self.losses.append(logs.get('loss'))
        self.accuracies.append(logs.get('acc'))
        

total = len(sys.argv)
cmdargs = str(sys.argv)

print ("Script name: %s" % str(sys.argv[0]))
checkpoint = None
if len(sys.argv) == 2:
    if os.path.exists(str(sys.argv[1])):
        print ("Checkpoint : %s" % str(sys.argv[1]))
        checkpoint = str(sys.argv[1])
        print("check point")

#data = pd.read_csv("DataforSVM.csv", header=0, delimiter=",", quoting=3)
#data = pd.read_csv("DataICDM_ALL.csv", header=0)
data = pd.read_csv("DataICADL_ALL_4300.csv", header=0)
#DataICADL_ALL_4300
txt = ''
docs = []
sentences = []
sentiments = []

for cont, sentiment in zip(data.text, data.label):
    #sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', clean(striphtml(cont)))
    #print(cont)
    sentences =  [sent.lower() for sent in cont]
    #print("sentence")
    #print(sentences)
    docs.append(sentences)
    sentiments.append(sentiment)

num_sent = []
for doc in docs:
    num_sent.append(len(doc))
    for s in doc:
        txt += s

chars = set(txt)

print('total chars:', len(chars))
char_indices = dict((c, i) for i, c in enumerate(chars))
indices_char = dict((i, c) for i, c in enumerate(chars))

print('Sample doc{}'.format(docs[100]))

maxlen = 512
max_sentences = 15

X = np.ones((len(docs), max_sentences, maxlen), dtype=np.int64) * -1
y = np.array(sentiments)

for i, doc in enumerate(docs):
    for j, sentence in enumerate(doc):
        if j < max_sentences:
            for t, char in enumerate(sentence[-maxlen:]):
                X[i, j, (maxlen - 1 - t)] = char_indices[char]

print('Sample chars in X:{}'.format(X[100, 2]))
print('y:{}'.format(y[100]))

ids = np.arange(len(X))
np.random.shuffle(ids)

# shuffle
X = X[ids]
y = y[ids]
#############3
# Use label_binarize to be multi-label like settings
Y = label_binarize(y, classes=[0, 1, 2,3])
n_classes = Y.shape[1]

# Split into training and test
random_state = np.random.RandomState(0)
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=.4,
                                                    random_state=random_state)
#X_train = X[:3000]
#X_test = X[3000:]
f = open("evaluation_results_testing_icadl.csv", "a")
f.write("Precision,Recall\n")
f.flush()
#y_train = y[:3000]
#y_test = y[3000:]

filter_length = [5, 3, 3]
nb_filter = [196, 196, 256]
pool_length = 2
# document input
document = Input(shape=(max_sentences, maxlen), dtype='int64')
# sentence input
in_sentence = Input(shape=(maxlen,), dtype='int64')
# char indices to one hot matrix, 1D sequence to 2D 
embedded = Lambda(binarize, output_shape=binarize_outshape)(in_sentence)
# embedded: encodes sentence
for i in range(len(nb_filter)):
    embedded = Conv1D(filters=nb_filter[i],
                      kernel_size=filter_length[i],
                      padding='valid',
                      activation='relu',
                      kernel_initializer='glorot_normal',
                      strides=1)(embedded)

    embedded = Dropout(0.1)(embedded)
    embedded = MaxPooling1D(pool_size=pool_length)(embedded)

bi_lstm_sent = \
    Bidirectional(LSTM(128, return_sequences=False, dropout=0.15, recurrent_dropout=0.15, implementation=0))(embedded)

# sent_encode = merge([forward_sent, backward_sent], mode='concat', concat_axis=-1)
sent_encode = Dropout(0.3)(bi_lstm_sent)
# sentence encoder
encoder = Model(inputs=in_sentence, outputs=sent_encode)
encoder.summary()

encoded = TimeDistributed(encoder)(document)
# encoded: sentences to bi-lstm for document encoding 
b_lstm_doc = \
    Bidirectional(LSTM(128, return_sequences=False, dropout=0.15, recurrent_dropout=0.15, implementation=0))(encoded)

output = Dropout(0.3)(b_lstm_doc)
output = Dense(128, activation='relu')(output)
output = Dropout(0.3)(output)
output = Dense(4, activation='softmax')(output)

model = Model(inputs=document, outputs=output)

model.summary()

if checkpoint:
    model.load_weights(checkpoint)

# convert integers to dummy variables (i.e. one hot encoded)
#dummy_y = np_utils.to_categorical(encoded_Y)
file_name = os.path.basename(sys.argv[0]).split('.')[0]
check_cb = keras.callbacks.ModelCheckpoint('checkpoints_rnn_prresults/'+ file_name + '.{epoch:02d}-{val_loss:.2f}.hdf5',
                                           monitor='val_acc',
                                           verbose=0, save_best_only=True, mode='min')
#earlystop_cb = keras.callbacks.EarlyStopping(monitor='acc', patience=7, verbose=1, mode='auto')
history = LossHistory()
metrics = Metrics()
keras.optimizers.Adam(lr=0.001)
#sparse_categorical_crossentropy
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
print("start model Training")
print("start model Training")
#optimizer_exclude=cudnn

metrics = Metrics()
pandas.DataFrame(model.fit(X_train, y_train, validation_data=(X_test, y_test), batch_size=30,
          epochs=100, shuffle=True, callbacks=[check_cb,history,metrics]).history).to_csv("history_RNN_ICADL_prresults_Adam_0.001.csv")

print("Adam 0.001 done")
#f = open("evaluation_results_icadl.csv", "a")
#f.write("Precision,recall\n")
res=metrics.precision
with open("evaluation_results_precision_icadl.csv", "w") as output:
    writer = csv.writer(output, lineterminator='\n')
    for val in res:
        writer.writerow([val])  
res_recall=metrics.recall
with open("evaluation_results_recall_icadl.csv", "w") as output2:
    writer = csv.writer(output2, lineterminator='\n')
    for val in res_recall:
        writer.writerow([val]) 
#f.write(str(metrics.precision)+","+ str(metrics.recall)+"\n")
#f.flush()
#writer.close()
print(metrics.precision)
print(metrics.recall)
print("Adam 0.001 done")
#y_predict= mode.predict()
# just showing access to the history object

